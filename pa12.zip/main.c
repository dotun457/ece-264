#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pa12.h"

void FreeMemory(struct node** head);


int main(int argc, char **argv)
{
    if (argc < 4) {
        fprintf(stdout,"incorrect parameters");
        return EXIT_FAILURE;
    }
    int length = atoi(argv[2]);
    struct node* head = malloc(sizeof(struct node));
   
    init(&head, length);
    int k =atoi(argv[3]);
    int p = atoi(argv[4]);
    
    printf("\n");
    if (strcmp(argv[1],"-J") == 0) {
        josp(&head,k, p,length);
    }
    FreeMemory(&head);
    return EXIT_SUCCESS;
}

void FreeMemory(struct node** head)
{
    struct node ** temp = head;
    if ((*head) != NULL)
    {
        struct node * q = (*head)->next;
        free(*temp);
        while(q != NULL)
        {
            *temp = q;
            q = q->next;
            free(*temp);
        }
    }
    return;
}
