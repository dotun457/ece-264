#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include "pa03.h"
#define RANGE 10000

void cleanup(FILE * fpin, FILE * fpout)
{
	fclose (fpin);
	fclose (fpout);
}

// allocate a two dimensional array of
double * * allocateMemory(int nrow, int ncol)
{
	double * * data = (double **)malloc(sizeof(*data) * nrow);
    for (int i = 0; i < nrow; i++) {
        data[i] = (double*)malloc(sizeof(**data) * ncol);
    }
	return data;
}

void releaseMemory(double * * data, int nrow)
{
    for (int i = 0; i < nrow; i++) {
        free(data[i]);
    }
    free(data);
}

// read the data, return true if success, false if fail
bool readData(FILE * fpin, double * * data, int nval, int dim)
{
	int niter, diter;
	for (niter = 0; niter < nval; niter ++)
	{
		for (diter = 0; diter < dim; diter ++)
		{
			if (fscanf(fpin, "%lf", & data[niter][diter]) == 0)
			{
				return false;
			}
		}
	}
	return true;
}

// write the output centroids to the file
// check for all the NULL before calling this function, it does not check
void writeCentroids(FILE * fpout, double * * centroid, int kval, int dim){
  int kiter,diter;
  for (kiter = 0; kiter < kval; kiter ++)
  {
    for (diter = 0; diter < dim; diter ++)
    {
      //write to the file
      fprintf(fpout, "%lf ", centroid[kiter][diter]);
    }
    fprintf(fpout, "\n");
  }
}

//initilize function is to initilize the values for centroid
void initialize(double * * centroid, int kval, int dim)
{
	int kiter, diter;
	for (kiter = 0; kiter < kval; kiter ++)
	{
		for (diter = 0; diter < dim; diter ++)
		{
			int randval = - RANGE + (rand() % (2 * RANGE));
			centroid[kiter][diter] = randval;
		}
	}
}

int main(int argc, char * * argv)
{
	// argv[1]: name of input file
	// argv[2]: value of k
	// argv[3]: name of output file
	// argv[4]: (optional) seed for random numbers, use time if absent

	if (argc < 4)
	{
		fprintf(stderr, "argc is %d, not 4\n", argc);
		return EXIT_FAILURE;
	}
	FILE * fpin = fopen(argv[1], "r");
	if (fpin == NULL)
	{
		fprintf(stderr, "fopen %s fail\n", argv[1]);
		return EXIT_FAILURE;
	}
	int kval = (int) strtol(argv[2], NULL, 10);
	// convert long to in
	if (kval <= 0)
	{
		fprintf(stderr, "kval is %d, must be positive\n", kval);
		return EXIT_FAILURE;
	}
	FILE * fpout = fopen(argv[3], "w");
	if (fpout == NULL)
	{
		fclose (fpin);
		// was open successfully and needs to be closed
		fprintf(stderr, "fopen %s fail\n", argv[3]);
		return EXIT_FAILURE;
	}

	if (argc == 5)
	{
		int randseed = (int) strtol(argv[4], NULL, 10);
		if (randseed == -1)
		{
			srand(time(NULL));
		}
		else
		{
			srand(randseed);
		}
	}

	int nval;
	fscanf(fpin, "%d", & nval);
	if (nval < kval)
	{
		fprintf(stderr, "nval= %d must be greater than kval = %d\n",
				nval, kval);
		cleanup(fpin, fpout);
		return EXIT_FAILURE;
	}
	int dim;
	fscanf(fpin, "%d", & dim);
	if (dim < 2)
	{
		fprintf(stderr, "nval= %d must be greater than kval = %d\n",
				nval, kval);
		cleanup(fpin, fpout);
		return EXIT_FAILURE;

	}

	// allocate memory for the data points
	double * * datapoint = allocateMemory(nval, dim);
	if (datapoint == NULL)
	{
		cleanup(fpin, fpout);
		return EXIT_FAILURE;
	}
	// allocate memory for the centroid
	double * * centroid = allocateMemory(kval, dim);
	if (centroid == NULL)
	{
		cleanup(fpin, fpout);
		return EXIT_FAILURE;
	}

	// read the data from the file
	if (readData(fpin, datapoint, nval, dim) == false)
	{
		cleanup(fpin, fpout);
		return EXIT_FAILURE;
	}

	// initialize centroids within [-RANGE, RANGE] of every dimension
	initialize(centroid, kval, dim);

  //allocate memory for cluster
  int * cluster;
  cluster = malloc(sizeof(*cluster)*nval);
  if(cluster == NULL)
  {
		cleanup(fpin, fpout);
		return EXIT_FAILURE;
	}
  // initilize cluster values
  for(int niter = 0; niter < nval; niter++)
  {
    cluster[niter] = -1;
  }

  //now we will run our kmean algorithm
  kmean(kval, nval, dim, datapoint, centroid, cluster);


  //print all the centroids into a file
  writeCentroids(fpout, centroid, kval, dim);

  //free all the allocated spaces
  releaseMemory(datapoint, nval);
  releaseMemory(centroid, kval);
  free(cluster);
  //close all the files
  cleanup(fpin, fpout);
	return EXIT_SUCCESS;
}


int closestCentroid(int kval, int dim, const double * data, double * * centroid){
    int c_centroid = distance2(data, centroid[0], dim);
    int c_2 = 0;
    int mindex = 0;
    for (int i = 0; i < kval; i++) {
        c_2 = distance2(data, centroid[i], dim);
        if (c_2 < c_centroid) {
            c_centroid = c_2;
            mindex = i;
        }
    }
    return mindex;
}
double distance2(const double * datapoint, double * centroid, int dim){
    double sum = 0; // must initialize to zero
    for (int i = 0; i < dim; i++) {
        sum += (datapoint[i] - centroid[i]) * (datapoint[i] - centroid[i]);
    }
    return sum;
}


void kmean(int kval, int nval, int dim, double * * data, double * * centroid,int * cluster){
    int ct = 0;
    int flag = 1;
    double * old_centroid = calloc(dim,sizeof(*old_centroid));  //FREE
    double* total = malloc(sizeof(*total) * dim);
    for (int v = 0; v < dim; v++) {
        total[v] = 0;
    }
    
    while(flag == 1){
        flag = 0;
    for (int i = 0; i < nval; i++) {
        cluster[i] = closestCentroid(kval,dim,data[i],centroid);
    }
        
    for (int j = 0; j < kval; j++) {
            ct = 0;
            for (int e = 0; e < dim; e++) {
            old_centroid[e] = centroid[j][e];
        }
            for (int z = 0; z < nval; z++) {
            if (j == cluster[z]){
                 ct++;
                for (int k = 0; k < dim; k++) {
                    total[k] += data[z][k];  // sum of the datapoints at zth
                }
            }
        }
            if (ct != 0) {
                for (int i = 0; i < dim; i++) {
                    centroid[j][i] = total[i] / ct;
                }
            }
            else{
                for (int b = 0; b < dim; b++) {
                    centroid[j][b] = 0;
            }
            }
                for (int c = 0; c < dim; c++) {
                    if (old_centroid[c] != centroid[j][c]  ) {
                     flag = 1;
        
                     }
                }
                for (int i = 0; i < dim; i++) {
                    total[i] = 0;
                }
        }
    } ;
        
        
//releaseMemory(old_centroid,kval);
free(total);
free(old_centroid);

}



