#include <stdio.h>
#include <stdlib.h>
#include "pe11.h"

#ifndef PRINT
void print(struct node** head)
{
    while ((*head) != NULL){
        printf("%d", (*head) -> value);
        *head = (*head) -> next;
    }
    printf("\n");
}
#endif

#ifndef INSF
void insertFirst(struct node** head,struct node * n)
{
    if ((*head) != NULL) {
        n->next = *head;
    }
    
}
#endif

#ifndef INSA
void insertAt(struct node** head,struct node * n,int index)
{
    if ((*head) != NULL) {
        int ct = 0;
        struct node* temp = malloc(sizeof(temp)); // do in need allocation
        temp = (*head);
        while (temp != NULL) {
            if (ct == index) {
                n->next = temp->next;
                temp->next = n;
                break;
            }
            ct++;
            temp = temp->next;
        }
        free(temp);
    }
    
}

#endif

#ifndef INSL
void insertLast(struct node** head,struct node *n)
{
    if ((*head) != NULL) {
        struct node * temp = *head;
        n->next = NULL;
        while (temp != NULL) {
            temp = temp->next;
        }
        temp->next = n;
        free(temp);
    }
    
}
#endif

#ifndef DELFM
void deleteFirstMatch(struct node**head,int value)
{
    struct node * temp = (*head);
    if (temp != NULL) {
        struct node* q = temp->next;
        while ((q != NULL) && ((q -> value) != value)) {
            temp = temp->next;
            q = q ->next;
        }
        if (q != NULL) {
            temp->next = q->next;
            free(q);
        }
    }
    
}
#endif

#ifndef DelA
void deleteAt(struct node** head,int index)
{
    struct node* temp = *head;
    if (temp != NULL) {
        struct node* q = temp->next;
        int ct = 0;
        while (q != NULL) {
            if (ct == index) {
                temp->next = q->next;
                break;
            }
            temp = temp->next;
            q = q->next;
        }
        free(q);
    }
    
}
#endif

#ifndef DELAM
void deleteAllMatches(struct node** head,int value)
{
    struct node* temp = *head;
    if (temp != NULL) {
        struct node* q = temp->next;
        struct node* temp_2 = NULL;
        
        while (q != NULL) {
            if (q ->value == value) {
                temp->next = q->next;
                temp_2 = q;
                q = q->next;
                free(temp_2);
            }
            if (q == NULL) {
                break;
            }
            temp = temp->next;
            q = q->next;
        }
        free(temp_2);
        free(q);
        
    }
    free(temp);
}
#endif

#ifndef L
int getLength(struct node** head)
{
    int ct = 1;
    struct node* temp =  *head;
    while (temp != NULL) {
        ct++;
        temp = temp->next;
    }
    return ct;
}
#endif

#ifndef FREEMEM
void freeMemory(struct node** head)
{
    while ((*head) != NULL) {
        struct node* temp = (*head)->next;
        free(*head);
        *head = temp;
    }
    
}
#endif

