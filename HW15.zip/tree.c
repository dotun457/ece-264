#include "tree.h"
//void writeToReal(FILE* outp, FILE* inp);
#ifndef USIGN_TO_BIN
// function to create binary values from the input char values
char * UnSig2Bin(unsigned char value) {
    // determine the number of bits needed ("sizeof" returns bytes)
    // create mask which you would use for the getting each bit value
    // for loop to mast values and creating char array of bits
    int bit_mask = 0x80;
    char * bin_tmp = malloc(sizeof(* bin_tmp) * NUM_BITS);
    
    for (int i = 0; i < NUM_BITS; i++) {
        bin_tmp[i] = 0;
    }
    
    for (int i = 0; i < NUM_BITS; i++) {
        bin_tmp[i] = (!(!((bit_mask >> i) & (value)))) + '0';
    }
    return bin_tmp;
}

#endif

#ifndef WRITE_BINARY

// WriteInOrderBinary takes root and file * as input
// and creates binary representation of the tree as specified in the example
int WritePreOrderBinary(TreeNode * root, FILE *outptr){
    if (root == NULL) {
        return EXIT_SUCCESS;
    }
    unsigned char ch;
    if (root->leftChild == NULL && root->rightChild == NULL) {
        ch = '1';
        char * tmp = UnSig2Bin(root->data);
        fwrite(&ch, sizeof(unsigned char),1,outptr);
        fwrite(tmp,sizeof(char),NUM_BITS,outptr);
        free(tmp);
    }
    else{
        ch = '0';
        fwrite(&ch,sizeof(unsigned char),1,outptr);
    }
    WritePreOrderBinary(root->leftChild, outptr);
    WritePreOrderBinary(root->rightChild, outptr);
    
    return EXIT_SUCCESS;
}

int CreateBinaryFromTree(TreeNode * root, const char *outfile){
    FILE *tmp = tmpfile();
    FILE* fp = fopen(outfile,"wb");
    
    if (fp == NULL){
        return EXIT_FAILURE;
    }
    char ch = '0';
    int ret = WritePreOrderBinary(root, tmp);
    
    fwrite(&ch,sizeof(char),1,tmp);
    fseek(tmp,0,SEEK_SET);
    
    unsigned char ct;
    char temp_bin[NUM_BITS];
    for (int i = 0; i < NUM_BITS; i++) {
        temp_bin[i] = '0';
    }
    char * holder;
    
    while ((fread(temp_bin,sizeof(char),8,tmp)) == 8) {
        ct = strtol(temp_bin,&holder,2);
        fwrite(&ct,sizeof(char),1,fp);
        //reset
        for (int i = 0; i < NUM_BITS; i++) {
            temp_bin[i] = '0';
        }
        
        
    }
    ct = strtol(temp_bin,&holder,2);
    fwrite(&ct,sizeof(char),1,fp);
    fclose(fp);
    fclose(tmp);
    return ret;
}


#endif



#ifndef CLEAN_TREE

void CleanTree(TreeNode * root){
    if(root != NULL) {
        CleanTree( root->leftChild );
        CleanTree( root->rightChild );
        free(root);
        return;
    }
}
#endif





#ifndef BINARY_SEARCH_TREE

int IntCompare(const void * val1, const void * val2){
    return (*(unsigned char*)val1 - *(unsigned char*)val2);
}

TreeNode * CreateBinarySearchTree(long randomSeed, long numNodes){
    unsigned char * binArray = malloc(sizeof(unsigned char)*numNodes);
    if(binArray == NULL){
        printf("Memory allocation to array failed\n" );
        return NULL;
    }
    srand(randomSeed);
    // allocate values to array
    for(int index = 0; index < numNodes ; index++){
        binArray[index] = rand() % 256;
    }
    // sort the array
    qsort(binArray, numNodes, sizeof(unsigned char), IntCompare);
    
    // create bst from the sorted array
    TreeNode * root = CreateBST(binArray, 0, numNodes-1);
    free(binArray);
    return root;
    
}
// TreeNode *CreateBSTHelper()
TreeNode* CreateTreeNode(unsigned char value){
    TreeNode *newNode = malloc(sizeof(TreeNode));
    newNode->data = value;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    return newNode;
}

TreeNode *CreateBST(unsigned char *sortedArray, int start , int end){
    // int len = sizeof(sortedArray)/sizeof(int);
    if(start > end) return NULL;
    int mid = (start+end)/2;
    TreeNode *newNode = CreateTreeNode(sortedArray[mid]);
    newNode->leftChild = CreateBST(sortedArray, start, mid -1);
    newNode->rightChild = CreateBST(sortedArray, mid +1, end);
    return newNode;
}
#endif

/*void writeToReal(FILE* fp, FILE* tmp){ //outp ,
 unsigned char ct;
 //char * value = malloc(sizeof(* value) * NUM_BITS);
 char value[NUM_BITS + 1];
 value[8] = '\0';
 fread(value,sizeof(char),8,tmp);
 int k = 0;  //z
 char * p;
 while (1) {
 ct = strtol(value,&p,2);
 fwrite(&ct,sizeof(char),1,fp);
 //reset
 for (int i = 0; i < NUM_BITS; i++) {
 value[i] = '0';
 }
 k = fread(value,sizeof(char),8,tmp);
 if ( k < 8) {
 ct = strtol(value,&p,2);
 fwrite(&ct,sizeof(char),1,fp);
 break;
 }
 }
 }
 }
 */

