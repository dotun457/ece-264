#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "pe10.h"


int main(int argc, char **argv) {
    if (argc != 4) {
        fprintf(stdout, "incorrect input arguments");
        return EXIT_FAILURE;
    }
    int len = atoi(argv[1]);
    int k = atoi(argv[2]);
    int p = atoi(argv[3]);
    
    bool* arr = malloc(sizeof(bool) * len);
    for (int i = 0; i < len; i++) {
        arr[i] = 1;
    }
    josephus(arr, len, k,p);
    
    
    return EXIT_SUCCESS;
}

