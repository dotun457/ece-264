#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "pe07.h"


#ifndef INT
bool IsInteger(char* str, int index)
{
    int len_arr = strlen(str);
    char val = str[index];
    
    if (index == len_arr) {
        return true;
    }
    if (!isdigit(val)) {
        return false;
    }
    
    return IsInteger(str, index + 1);
}
#endif

#ifndef DOUBLE
bool IsDouble(char* str, int index,bool dot)
{
    int len_arr = strlen(str);
    char val = str[index];
    
    if (index == 0) {
        if (!isdigit(val)) {
            return false;
        }
    }
    
    if (index == (len_arr - 1)) {
        if (!isdigit(val)) {
            return false;                
        }
    }
    if (index == len_arr) {
        if (dot == true) {
            return true;
        }
    }
    
    if(!isdigit(val)){
        if (val == '.' && dot != true) {
            dot = true;
        }
        if (val != '.') {
             return false;
        }
       
    }
    
    return IsDouble(str,index + 1, dot);
}
#endif

#ifndef VALIDID
bool IsValidIdentifier(char* str, int index)
{
    int len_arr = strlen(str);
    char val = str[index];
    
    if (index == 0) {
        if (!isalpha(val)) {  //check if underscore
            if (val != '_') {
                return false;
           }
        }
    }
    
    if (index == len_arr) {
        return true;
    }
    if (!isdigit(val)) {
        if (!isalpha(val)) {
           if (val != '_') {
                return false;
            }
        }
    }
    
    return IsValidIdentifier(str, index + 1);
}
#endif

