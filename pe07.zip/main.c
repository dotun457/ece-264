#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include "pe07.h"
#define MAX_LENGTH 100 //The maximum length of string


int main(int argc, char *argv[])
{
    int ch = 0, num_lines = 0;
    bool res, t_1, t_2, t_3;
    bool dot = false;
    if (argc <= 1) {
        fprintf(stdout, "Wrong arguments\n");
        return EXIT_FAILURE;
    }
    
    FILE * fp = fopen(argv[1],"r");
    if (fp == NULL) {
        return EXIT_FAILURE;
    }
    fseek(fp, 0, SEEK_SET);
    while (!feof(fp)) {
        ch = fgetc(fp);
        if (ch == '\n') {
            num_lines++;
        }
    }
    char temp[MAX_LENGTH];
    fseek(fp , 0, SEEK_SET);
    if (argc >= 3) {
        for (int i = 0; i < num_lines; i++) {
            fscanf(fp, "%s ", temp);
            if (strcmp(argv[2], "-I") == 0) {
                res = IsInteger(temp, 0);
                if (res == true) {
                    fprintf(stdout, "Integer\n");
                }
                if (res == false) {
                    fprintf(stdout, "Not integer\n");
                }
            }
            if (strcmp(argv[2], "-D") == 0) {
                res = IsDouble(temp, 0, dot);
                if (res == true) {
                    fprintf(stdout, "Double\n");
                }
                if (res == false) {
                    fprintf(stdout, "Not double\n");
                }
            }
            if (strcmp(argv[2], "-VID") == 0) {
                res = IsValidIdentifier(temp, 0);
                if (res == true) {
                    fprintf(stdout, "Identifier\n");
                }
                if (res == false) {
                    fprintf(stdout, "Not identifier\n");
                }
            }
            
        }
    }
    
    char temp2[MAX_LENGTH];
    if (argc < 3) {
        for (int i = 0; i < num_lines; i++) {
            fscanf(fp, "%s ", temp2);
            t_1 = IsInteger(temp2,0);
            t_2 = IsDouble(temp2,0,dot);
            t_3 = IsValidIdentifier(temp2,0);
            if (t_1 == true) {
                fprintf(stdout,"Integer\n");
                
            }
            if (t_2 == true) {
                fprintf(stdout,"Double\n");
                
            }
            if (t_3 == true) {
                fprintf(stdout,"Identifier\n");
               
            }
            if (t_1 == false && t_2 == false && t_3 == false) {
                fprintf(stdout,"None\n");
                
            }
        }
    }
    
   
    fclose(fp);
    
    return EXIT_SUCCESS;
}


