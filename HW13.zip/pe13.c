#include "frequency.h"

// Step 1. - Create/ Define data structre in frequency.h such that it can hold character of 256 bytes
// Step 2. - Complete function in frequency.c file
// Step 3. - Complete main function
// Step 4. - Test all the test cases


int main(int argc, char **argv){
    //0. Create array of CharFreq
    
    //1. initialize all the frequencies inside freq array to be 0
    //2. Count Frequency from the the input file
    //2a. if return value from the function is not success, return exit failure
    //3. Sort frequencies that you get
    //4. Print the frequencies on terminal
    if (argc != 2) {
        return EXIT_FAILURE;
    }
    CharFreq* arr = malloc(sizeof(CharFreq) * NUMLETTER);
    for (int i = 0; i < NUMLETTER; i++) {
        arr[i].freq = 0;
    }
    //for (int i = 0; i < NUMLETTER; i++) {
    CountFrequency(argv[1], arr);
    //}
    //SortFrequency(arr);
    PrintFreq(arr);
    
    
    /* CharFreq* arr = calloc(NUMLETTER, sizeof(CharFreq));
     
     
     //for (int i = 0; i < NUMLETTER; i++) {
     CountFrequency(argv[1], arr);
     }
     SortFrequency(arr);
     PrintFreq(arr);*/
    
    free(arr);
    return EXIT_SUCCESS;
}

