#include <stdio.h>
#include <stdlib.h>
#include "pa08.h"
void convul(char * string, int min,int  max,int index, int l_dex,int iteration,char * temp_string);

#ifndef CDOUBLE
void createDouble(char * string,DoubleVar* var,int index,bool dot,int len)
{
    int temp_len = sizeof(string) / sizeof(char);
    char * temp_string = malloc(sizeof(*temp_string)* temp_len);
    int val;
    int min = var->digit_start;
    int max = var->digit_end;
    
    for (val = 3;  val <= len ; val++) {
        convul(string,min,max,index, (val-1) , 0,temp_string);
    }
    free(temp_string);
    
}
#endif

void convul(char * string, int min,int  max,int index, int l_dex,int iteration,char * temp_string){  //min smallest number and max is largest number
    
    string[index] = min + iteration; //start is the starting character in the string
    if (string[index] > max) {
        return;
    }
    
    
    if (index == l_dex ) {            // is the last index
        int i = 1;
        char temp_char;
        do{
        // I want to print for last index
            temp_char = string[i];
            if (string[i] == max){
                string[i] = '.';
                fprintf(stdout,"%s\n",string);   //print out if index is l_dex
                string[i] = temp_char;
            }
            i++;
        }while(i < l_dex);
    }
    
    
    if (index != l_dex) {
        convul(string, min, max, index + 1, l_dex, 0, temp_string);
    }
    if (string[index] < max) {
        convul(string, min, max, index, l_dex,iteration + 1, temp_string);
    }
    return;
    
}


#ifndef CVID
void createVID(char * string,VIDVar * var,int index,int len)
{
	
}
#endif

