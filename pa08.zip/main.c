#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pa08.h"


int main(int argc, char *argv[]) {
    if (strcmp(argv[1],"-D") == 0) {
        int max_len = atoi(argv[4]);
        char * string = malloc(sizeof(*string) * max_len);
        DoubleVar* var = malloc(sizeof(*var));
        var->digit_start = (char)argv[2][0];
        var->digit_end = (char)argv[3][0];
        createDouble(string,var, 0, false, max_len);
        free(var);
        free(string);
    }
	return EXIT_SUCCESS;
}
