#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pa09.h"

#ifndef CONNECT

StudentDatabase * ReadDatabase(char * filename) {
    //TODO 1. Open the file in read and binary format
    //TODO 2. Allocate memory for db
      //TODO 3. Find number to entries of Student structure
    // TODO 5. Allocate the memory for the db->students structure
    //TODO 6. Read the file again from start and assign value to each student in the data base
    //db->students[i] = calloc(1, sizeof(Student));
        //close the file
    //return the StudentDatabase
    int i;
    int num_stud = 0;
    StudentDatabase * db = NULL;
    db = malloc(sizeof(*db));
    
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        return NULL;
    }
    Student * sdub = malloc(sizeof(*sdub));
    fseek(fp,0, SEEK_SET);
    while (fread(sdub, sizeof(Student), 1, fp)) {
        num_stud++;
    }
    free(sdub);
    
    fseek(fp,0,SEEK_SET);
    
    db->number = num_stud;
    
    db->students = malloc(sizeof(Student*) * db->number);
    for (i = 0; i < db->number; i++) {
        db->students[i] = malloc(sizeof(Student));
    }
    for (i = 0; i < db->number; i++) {
        fread(db->students[i],sizeof(Student),1,fp);
    }
    fclose(fp);
    return db;
}

#endif

#ifndef WRITE_DB
//This function is to write to a file in binary format
int WriteDatabase(char *filename, StudentDatabase * db) {
    //TODO 1. Open the file in write and binary format
    //TODO 2. check if the StudentDatabase is not null
    //TODO 3. write into the file and if not possible return 0
    size_t ct;
    FILE* fp = fopen(filename, "w");
    if (fp == NULL) {
        return 0;
    }
    if (db == NULL) {
        return 0;
    }
    for (int i = 0; i < db->number; i ++) {
        ct = fwrite(db->students[i], sizeof(Student), 1, fp);
        if (ct != 1) {
            return 0;
        }
    }
    return 1;
    
    
}
#endif


