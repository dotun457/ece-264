#include "frequency.h"
static int compareFreq( const void * p1 , const void * p2 );
// Counting the frequencies of the characters in the frequency table
#ifndef COUNT_FREQ
int CountFrequency(char * filename, CharFreq * freq){
    // as compared to HW13 please do not exclude newline character.
    FILE * fp = fopen(filename,"r");
    if (fp == NULL) {
        //fclose(fp);
        return 0;
    }
    fseek(fp,0,SEEK_SET);
    int ch = 0;
    while (ch != EOF) {
        ch = fgetc(fp);
        freq[ch].data = ch;
        freq[ch].freq++;
    }
    fclose(fp);
    
    return EXIT_SUCCESS;
}

#endif

#ifndef SORT_FREQ


// Sort function for sorting frequencies
void SortFrequency(CharFreq * freq){
    qsort( freq , NUMLETTER , sizeof(CharFreq), compareFreq);
}
#endif


static int compareFreq( const void * p1 , const void * p2 )
{
    int cptr = 0;
    const CharFreq * ip1 = (const CharFreq *) p1 ;
    const CharFreq * ip2 = (const CharFreq *) p2 ;
    const int iv1 = ip1 -> freq;
    const int iv2 = ip2 -> freq;
    int c1 = ip1->data;
    int c2 = ip2->data;
    cptr = iv1 - iv2;
    if (cptr == 0) {
        return (c1 - c2);
    }
    return (cptr);
}
