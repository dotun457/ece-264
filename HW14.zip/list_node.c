#include "list_node.h"

// Create the list node from treenode as input
#ifndef LIST_CREATE
ListNode * ListNodeCreate(TreeNode * treenode){
    ListNode* node = malloc(sizeof(ListNode));
    node->treeNodePtr = treenode;
    node->next = NULL;
    return node;
}

#endif

#ifndef LIST_BUILD
ListNode * ListBuild(CharFreq * freqArray){
    int i = 0;
    // find the first index with non-zero frequency
    // if all are character have zero freq then return nothing
    ListNode * head = NULL;
    int ct = 0;
    for (i = 0; i < NUMLETTER; i++) {
        if (freqArray[i].freq == 0) {
            ct++;
        }
    }
    if (ct == NUMLETTER) {
        return NULL;
    }
    for (i = 0; i < NUMLETTER ; i++) {
        if (freqArray[i].freq != 0) {
            TreeNode* tree = TreeNodeCreate(freqArray[i].data,freqArray[i].freq);
            ListNode* l_node = ListNodeCreate(tree);
            head = ListInsert(head,l_node);
        }
        
    }
    
    // build the linked list such that lower frequency comes first and then higher
    return head;
}
#endif




#ifndef LIST_INSERT

ListNode * ListInsert(ListNode * head, ListNode * listNode){
    // insert such that lower frequency comes before the already inserted frequency
    // if the frequencies are same for the nodes, then inserted node should come after the compared node
    if (head == NULL) {
        return listNode;
    }
    if (listNode->next != NULL) {
        fprintf(stdout,"ERROR in ListInsert: listNode->next is NULL");
        return NULL;
    }
    if (head->treeNodePtr->freq > listNode->treeNodePtr->freq) {
        listNode->next = head;
        return listNode;
    }
    ListNode* temp = head;
    while ( (temp->next != NULL) &&  ((temp->next)->treeNodePtr->freq <= (listNode->treeNodePtr)->freq)  ) {
        
        temp = temp->next;
    }
        listNode->next = temp->next;
        temp->next = listNode;
 
    return head;
}

#endif

#ifndef LIST_CLEAN

void CleanList(ListNode *head){
    ListNode* temp = head;
    if (head != NULL) {
        ListNode* q = head->next;
        while (q != NULL) {
            temp = q;
            q = q->next;
            free(temp);
        }
        free(head);
    }
    // clean the ListNode
}

#endif

#ifndef HUFFMAN_BUILD
// builds the huffman tree from the linked list
ListNode * BuildHuffmanTree(ListNode *head){
    
    while ((head->next)  != NULL) {
        ListNode* temp = head;
        ListNode* temp1 = head->next;
        ListNode* temp2 = temp1->next;
        
        TreeNode* tree1 = temp->treeNodePtr;
        TreeNode* tree2 = temp1->treeNodePtr;
        
       free(temp);
       free(temp1);
       head = temp2;
        
        TreeNode* new = TreeMerge(tree1,tree2);
        ListNode* node = ListNodeCreate(new);
        head = ListInsert(head,node);
    }
    return head;
}

#endif



