#include "bmpfunc.h"
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))
int avg_cells(char * * grayImage, int x_o,int y_o,int radius,int row,int col);

#ifndef FUNC_GIVEN

int RGB2Gray(unsigned char red, unsigned char green, unsigned char blue){
    // this is a commonly used formula
    double gray = 0.2989 * red + 0.5870 * green + 0.1140 * blue;
    return (int) gray;
}

#endif


#ifndef IMG_TO_GRAY

BMPImage * ImgToGray(BMPImage * image){
    
    // allocate space for the image
    // the image has the same size
    // therefore the header has to stay the same
    BMPImage* gray_image = malloc(sizeof(BMPImage));
    
    gray_image->header = image->header;
    
    int width = (image ->header). width ;
    int height = (image ->header). height ;
    char * * twoDGray = malloc ( sizeof ( char *) * height ) ;
    int row ;
    int col ;
    for ( row = 0; row < height ; row ++)
    {
        twoDGray [ row ] = malloc ( sizeof( char *) * width );
    }
    int pxl = 0;
    for ( row = 0; row < height ; row ++)
    {
        for ( col = 0; col < width ; col ++)
        {
            twoDGray [ row ][ col ] = RGB2Gray ( image -> data [ pxl + 2] ,
                                                image -> data [ pxl + 1] ,
                                                image -> data [ pxl ]) ;
            pxl += 3;
        }
    }
    
    pxl = 0;
    gray_image->data = malloc(sizeof(unsigned char) * height * width);
    for (int i = 0; i < height; i++) {
        for (int k = 0; k < width; k++) {
            //for ( pxl = 0; pxl < (gray_image->header.size); pxl ++ ) {
            gray_image->data[pxl+ 2] = twoDGray[i][k];
            gray_image->data[pxl+ 1] = twoDGray[i][k];
            gray_image->data[pxl] = twoDGray[i][k];

            pxl += 3;
        }
        
    }
    
    
    for (int i = 0; i < height; i++) {
        free(twoDGray [ i ]);
    }
    free(twoDGray);
    return gray_image;
    
}

#endif


#ifndef ADAPTIVE_THRESHOLDING

BMPImage * AdaptiveThresholding(BMPImage * grayImage, int radius, int epsilon){
    // allocate space for the image
    // the image has the same size
    // therefore the header has to stay the same
    BMPImage* adaptive = malloc(sizeof(BMPImage));
    adaptive->header = grayImage->header;
    
    int row = (grayImage->header).height;
    int col = (grayImage->header).width;
    int avg = 0;
    
    adaptive->data = malloc(sizeof(unsigned char ) * row * col);
    char ** g_palt = malloc(sizeof(unsigned char * ) * row );
    
    for (int i = 0; i < row; i++) {
        g_palt[i] = malloc(sizeof(unsigned char*) * col);
    }
    
    int plx = 0;
    for (int i = 0; i < row; i++) {
        for (int k = 0; k < col; k++) {
            g_palt[i][k] = grayImage->data[plx];
            plx += 3;
        }
    }
    
    plx = 0;
    
    
    for (int i = 0; i < row; i++) {
        for (int k = 0; k < col; k++) {
            avg = avg_cells(g_palt, i, k ,radius,row,col);
            if (g_palt[i][k] <=  (avg - epsilon)) {
                adaptive->data[plx+ 2] = 0;
                adaptive->data[plx+ 1] = 0;
                adaptive->data[plx] = 0;
            }
            else if (g_palt[i][k] >=  (avg - epsilon)){
                adaptive->data[plx+ 2] = 255;
                adaptive->data[plx+ 1] = 255;
                adaptive->data[plx] = 255;
            }
            plx += 3;
        }
    }
    for (int i = 0; i < row; i++) {
        free(g_palt [ i ]);
    }
    free(g_palt);
    //free(grayImage->data);
    //BMP_Free(grayImage);
    return adaptive;
    
}


#endif
int avg_cells(char * * grayImage, int x_o,int y_o,int radius,int row,int col){
    int ct = 1;
    int avg = 0;
    int sum = 0;
    
    for (int i = x_o - radius; i <= x_o + radius; i++) {
        for (int k = y_o - radius; k <= y_o + radius; k++) {
            if( i >= 0 && (k) >= 0 && (i) < (row ) && (k) < col){
                sum += grayImage[i][k];
                ct++;
            }
            
        }
    }
    avg = sum / ct;
    return avg;
}


