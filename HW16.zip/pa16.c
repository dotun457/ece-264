#include "pa16.h"

#ifndef MAIN_FUNC

int main(int argc, char **argv){
    // check the arguments
    // check radius and epsilon values
    // open the BMP file
    // convert to gray scale
    // check for error in converting to gray scale
    
    // call adaptive threshold function
    // check for errors after calling adaptive threshold
    // write the adaptive threshold image to file
    // free all the images
    if (argc != 5) {
        printf("wrong argumemts \n");
        return EXIT_FAILURE;
    }
    
    BMPImage * img = BMP_Open(argv[1]);
    if (img == NULL) {
        printf("Error opening BMP file");
        return EXIT_FAILURE;
    }
    
    if (atoi(argv[3]) < 0) {
        printf("Wrong inputs\n");
        return EXIT_FAILURE;
    }
    if (atoi(argv[4]) < 0) {
        printf("Wrong inputs");
        return EXIT_FAILURE;
    }
    int radius = atoi(argv[3]);
    int epsilon = atoi(argv[4]);
    
    BMPImage * grayImage = ImgToGray(img);
    
    
    BMPImage * adaptive = AdaptiveThresholding(grayImage,radius,epsilon);
    if (adaptive == NULL) {
        printf("Error in Adaptive Gray image\n");
        return EXIT_FAILURE;
    }
   
    int suc = BMP_Write(argv[2],adaptive);
    if (suc != 1) {
        BMP_Free(adaptive);
        return EXIT_FAILURE;
    }
    
    //BMP_Free(grayImage);
    //BMP_Free(adaptive);
    return EXIT_SUCCESS;
}

#endif


