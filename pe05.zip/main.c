#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pe05.h"


/*
	Complete the main function and meet the followin specifications of argc and argv.
	1. argc: If argc is not 4, you should return `EXIT_FAILURE` and print "Wrong arguments\n".
	2. argv[1]: name of the database. i.e., database.txt.
	3. argv[2]: should be either "-a", or "-n".
		When argv[2] is "-a", you should sort the database by age in ascending order and write the database to a file and return `EXIT_SUCCESS`.
		When argv[2] is "-n", you should sort the database by name in descending order and write the dataabse to a file and return `EXIT_SUCCESS`. 
		For example, Student "Allen" should come after "Bob".
	  	If argv[2] is neither "-a" nor "-n", you should print "Wrong arguments\n" and return `EXIT_FAILURE`.
	4. argv[3]: This is the output filename. You should write the output of database into this file.
	5. print "Write to db\n" to screen if `WriteDatabase()` work. Otherwise, print "Fail to write to db\n"

*/ 

int main(int argc, char ** argv) {
    if (argc != 4) {
        fprintf(stdout,"Wrong arguments\n");
        return EXIT_FAILURE;
    }
    if (argv[1] != NULL) {
        StudentDatabase* studb =  Connect(argv[1]);
        if (studb == NULL) {
            fprintf(stdout,"Fail to connect to db.\n");
            return EXIT_FAILURE;
        }
        if (strcmp(argv[2],"-a") == 0) {
            SortDatabaseByAge(studb);
            int test1 = WriteDatabase(argv[3],studb);
            if (test1 == 1) {
                fprintf(stdout,"Write to db\n");
                return EXIT_SUCCESS;
            }
            else if (test1 == 0){
                fprintf(stdout,"Fail to write to db\n");
                return EXIT_FAILURE;
            }
            return EXIT_SUCCESS;
        }
        if  (strcmp(argv[2],"-n") == 0) {
            SortDatabaseByName(studb);
            int test = WriteDatabase(argv[3],studb);
            if (test == 1) {
                fprintf(stdout,"Write to db\n");
                return EXIT_SUCCESS;
            }
            else if (test == 0){
                fprintf(stdout,"Fail to write to db\n");
                return EXIT_FAILURE;
            }
            return EXIT_SUCCESS;
        }
        if (( strcmp(argv[2],"-a") != 0 || (strcmp(argv[2],"-n") != 0) )) {
            fprintf(stdout, "Wrong arguments\n");
            return EXIT_FAILURE;
        }
        Close(studb);

    }
    
	return EXIT_SUCCESS;
}


