#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pe05.h"

#ifndef TEST_CPRNAME
static int CompareByName(const void * s1, const void * s2) {
    Student** n1 = (Student**)s1;
    Student** n2 = (Student**)s2;

    return (-strcmp((*n1)->name,(*n2)->name));
}
#endif

#ifndef TEST_NAME
void SortDatabaseByName(StudentDatabase * studb) {
    qsort(studb->students, studb->number, sizeof(Student*), CompareByName);
}
#endif

#ifndef TEST_CPRAGE
static int CompareByAge(const void * s1, const void * s2) {
    Student** a1 = (Student**)s1;
    Student** a2 = (Student**)s2;
    
    return ((*a1)->age - (*a2)->age);
}
#endif

#ifndef TEST_AGE
void SortDatabaseByAge(StudentDatabase * studb) {
    qsort(studb->students, studb->number, sizeof(Student*), CompareByAge);
}
#endif

#ifndef TEST_WRITE
int WriteDatabase(char *filename, StudentDatabase * db) {
    // Write the info storing in db to filename
    //open the file
    FILE* fp = fopen(filename, "w");
    if (fp == NULL) {
        fprintf(stdout, "Fail to open a file\n");
        return 0;
    }
    if (fp != NULL) {
        fseek(fp,0,SEEK_SET);
        for (int i = 0; i < db->number; i++) {
            fprintf(fp, "ID:%d, Name:%s, Major:%s, Enrollment:%s, Year:%s, Age:%d \n",db->students[i]->id,db->students[i]->name,db->students[i]->major,db->students[i]->enrollment,db->students[i]->year,db->students[i]->age); //id, name, students, major, year, enrollment, age
        }
    }
    
    fclose(fp);
    return 1;
    
}
#endif

